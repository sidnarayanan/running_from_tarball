"""
A set of algorithms that try something, and if that fails tries it again.
"""