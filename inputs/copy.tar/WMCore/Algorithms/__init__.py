#!/usr/bin/env python
"""
__init__

"""

__all__ = []

__revision__ = "$Id: __init__.py,v 1.1 2009/04/24 21:36:01 swakef Exp $"
__version__ = "$Revision: 1.1 $"


