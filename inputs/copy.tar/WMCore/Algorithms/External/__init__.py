#!/usr/bin/env python
"""
__init__

"""

__all__ = []

__revision__ = "$Id: __init__.py,v 1.1 2009/10/29 20:53:28 mnorman Exp $"
__version__ = "$Revision: 1.1 $"


