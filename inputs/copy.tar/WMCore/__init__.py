#!/usr/bin/env python
"""
_WMCore_

Core libraries for Workload Management Packages

"""
__all__ = []
__revision__ = "$Id: __init__.py,v 1.2 2008/09/29 16:10:57 fvlingen Exp $"
__version__ = "$Revision: 1.2 $"
__author__ = "fvlingen@caltech.edu"


