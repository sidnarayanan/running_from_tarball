#!/usr/bin/env python
"""
_MCPayloads_

Definitions for standard XML Tree based representations of abstract workflows
and concrete job specifications for use withing the ProdAgent system

"""
__revision__ = "$Id: __init__.py,v 1.3 2006/12/04 13:29:31 evansde Exp $"
__version__ = "$Revision: 1.3 $"
__author__ = "evansde@fnal.gov"
__all__ = []

