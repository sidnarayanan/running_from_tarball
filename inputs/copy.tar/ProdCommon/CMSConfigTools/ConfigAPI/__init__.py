#!/usr/bin/env python
"""
_ConfigAPI_

Wrappers/Utils around the CMSSW Python API for configuring executables

"""
__all__ = []
