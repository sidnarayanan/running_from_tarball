#!/usr/bin/env python
"""
_CMSConfigTools_

Python API for dealing with Python format CMSSW PSet Config Files

"""
__version__ = "$Revision: 1.2 $"
__revision__ = "$Id: __init__.py,v 1.2 2006/12/04 13:23:33 evansde Exp $"

__all__ = []

