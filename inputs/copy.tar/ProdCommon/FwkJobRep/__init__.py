#!/usr/bin/env python
"""
_FwkJobRep_

Python object support and parsers for generating/manipulating Framework
Job Reports.

Runtime Safe.


"""
__version__ = "$Revision: 1.1 $"
__revision__ = "$Id: __init__.py,v 1.1 2008/01/03 16:08:13 evansde Exp $"
__author__ = "evansde@fnal.gov"
__all__ = []



